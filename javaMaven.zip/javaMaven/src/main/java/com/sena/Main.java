package com.sena;
import java.sql.Date;
import java.util.Scanner;

import com.sena.DAO.DAOConductor;
import com.sena.DAO.DAOVehiculo;
import com.sena.models.Conductor;
import com.sena.models.Vehiculo;
import com.sun.javafx.binding.StringFormatter;

public class Main {

    public static void main(String[] args) {

        DAOVehiculo dao = new DAOVehiculo();
        DAOConductor daoC = new DAOConductor();
        Scanner sc = new Scanner(System.in);
        Scanner cs = new Scanner(System.in);

        Vehiculo c = new Vehiculo();
        Conductor n = new Conductor();


        //-----INGRESAR UN NUEVO CONDUCTOR
        System.out.println("\n INGRESAR NUEVO CONDUCTOR");
        System.out.println("Ingrese Nombre completo del Conductor: ");
        String nombreCompleto = sc.nextLine();
        n.setNombreCompleto(nombreCompleto);

        System.out.println("Ingrese el Telefono del Conductor: ");
        String telefono = sc.nextLine();
        n.setTelefono(telefono);

        System.out.println("Ingrese Direccion del Conductor: ");
        String direccion = sc.nextLine();
        n.setDirreccion(direccion);

        daoC.createConductor(n);


        //-----CAMBIAR DIRECCION DEL CONDUCTOR
        System.out.println("\nCAMBIAR DIRECCION DEL CONDUCTOR");
        System.out.println("Ingrese id del Conductor: ");
        int idM = sc.nextInt();
        System.out.println("Ingrese Nueva Direccion del Conductor: ");
        String direccionNuv = cs.nextLine();
        n.setDirreccion(direccionNuv);
        daoC.updateConductor(idM,n);

        //-----CONSULTAR TODOS LOS CONDUCTORES
        System.out.println("\nBASE DE DATOS");
        daoC.consultarConductores();

        //-----CONSULTAR UN SOLO CONDUCTOR
        System.out.println("\nCONSULTAR UN CONDUCTOR");
        System.out.println("Ingrese id del Conductor para consultar: ");
        int idC = sc.nextInt();
        daoC.ConsusltarConductor(idC);

        //-----ELIMINAR
        System.out.println("\nELIMINAR CONDUCTOR");
        System.out.println("Ingrese id del Conductor para ELiminar: ");
        int idE = sc.nextInt();
        daoC.deleteConductor(idE);





        //-----INGRESAR UN NUEVO VEHICULO
        System.out.println("\nINGRESAR UN NUEVO VEHICULO");
        System.out.println("Ingrese la Marca del Vehiculo: ");
        String marc = sc.nextLine();
        c.setMarca(marc);

        System.out.println("Ingrese el Modelo del Vehiculo: ");
        String model = sc.nextLine();
        c.setModelo(model);

        System.out.println("Ingrese la Placa del Vehiculo: ");
        String plac = sc.nextLine();
        c.setPlaca(plac);

        System.out.println("Ingrese el Valor Comercial del Vehiculo: ");
        double valor = sc.nextDouble();
        c.setValorComercial(valor); sc.nextLine();

        dao.createVehiculo(c);


        //-----ELIMINAR UN VEHICULO
        System.out.println("\nELIMINAR UN VEHICULO");
        System.out.println("Ingrese la Placa del Vehiculo para eliminar: ");
        String placa = sc.nextLine();
        c.setPlaca(placa);
        dao.deleteVehiculo(c);

        //-----CAMBIAR VALOR COMERCIAL DE UN VEHICULO
        System.out.println("\nCAMBIAR VALOR COMERCIAL DE UN VEHICULO");
        System.out.println("Ingrese la Placa del Vehiculo para cambiar el Valor Comercial: ");
        String pla = sc.nextLine();
        c.setPlaca(pla);
        System.out.println("Ingrese el nuevo Valor Comercial del Vehiculo: ");
        double valo = sc.nextDouble();
        c.setValorComercial(valo);
        dao.updateVehiculo(c);

    }
}











