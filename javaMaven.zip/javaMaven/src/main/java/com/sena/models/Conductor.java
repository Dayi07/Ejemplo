package com.sena.models;

import java.sql.Date;

public class Conductor {
    private int id;
    private String NombreCompleto;
    private String Telefono;
    private String Direccion;
    private Date FechaCreacion;

    public Conductor(){

    }

    public Conductor(String NombreCompleto, String Telefono, String Dirreccion, Date FechaCreacion){
        this.NombreCompleto = NombreCompleto;
        this.Telefono = Telefono;
        this.Direccion = Dirreccion;
        this.FechaCreacion = FechaCreacion;
    }

    public Conductor(int id, String NombreCompleto, String Telefono, String Dirreccion, Date FechaCreacion){
        this.id = id;
        this.NombreCompleto = NombreCompleto;
        this.Telefono = Telefono;
        this.Direccion = Dirreccion;
        this.FechaCreacion = FechaCreacion;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombreCompleto() {
        return NombreCompleto;
    }

    public void setNombreCompleto(String nombreCompleto) {
        NombreCompleto = nombreCompleto;
    }

    public String getTelefono() {
        return Telefono;
    }

    public void setTelefono(String telefono) {
        Telefono = telefono;
    }

    public String getDireccion() {
        return Direccion;
    }

    public void setDirreccion(String dirreccion) {
        Direccion = dirreccion;
    }

    public Date getFechaCreacion() {
        return FechaCreacion;
    }

    public void setFechaCreacion(Date fechaCreacion) {
        FechaCreacion = fechaCreacion;
    }
}
