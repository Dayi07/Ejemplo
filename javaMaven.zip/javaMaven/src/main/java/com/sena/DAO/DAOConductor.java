package com.sena.DAO;

import com.sena.conexion.Conexion;
import com.sena.models.Conductor;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;


public class DAOConductor extends Conexion {

    public void createConductor(Conductor n){
        Connection con = this.getConexion();
        String sql = "INSERT INTO Conductor (NOMBRECOMPLETO, TELEFONO, DIRECCION, FECHACREACION) VALUES(?, ?, ?, now())";
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, n.getNombreCompleto());
            ps.setString(2, n.getTelefono());
            ps.setString(3, n.getDireccion());

            System.out.println(ps.toString());
            ps.execute();

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public void deleteConductor(int id){
        Connection con = this.getConexion();
        String sql = "DELETE FROM Conductor WHERE ID = (?) ";
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, id);

            System.out.println(ps.toString());
            ps.execute();

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public void updateConductor(int id, Conductor n){
        Connection con = this.getConexion();
        String sql = "UPDATE Conductor SET DIRECCION = (?) WHERE ID = (?)";
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, n.getDireccion());
            ps.setInt(2, id);

            System.out.println(ps.toString());
            ps.execute();

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

    }


    public void consultarConductores(){
        List<Conductor> ConductorList = new ArrayList<>();
        Connection con = this.getConexion();
        String sql = "SELECT * FROM Conductor";

        try{
            PreparedStatement ps = con.prepareStatement(sql);
            System.out.println(ps.toString());
            ResultSet rs = ps.executeQuery();
            while (rs.next()){
                Conductor conductor = new Conductor(rs.getInt("ID"),
                        rs.getString("NOMBRECOMPLETO"),
                        rs.getString("TELEFONO"),
                        rs.getString("DIRECCION"),
                        rs.getDate("FECHACREACION"));

                ConductorList.add(conductor);
                System.out.println(conductor.getId() + " " + conductor.getNombreCompleto() + " " + conductor.getTelefono() + " " + conductor.getDireccion() + " " + conductor.getFechaCreacion());

            }

        }catch (SQLException e){
            System.out.println(e.getMessage());

        }
    }

    public void ConsusltarConductor(int id){
        Connection con = this.getConexion();
        String sql = "SELECT * FROM Conductor WHERE ID = (?) ";
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            System.out.println(ps.toString());
            ResultSet rs = ps.executeQuery();
            while (rs.next()){

                Conductor conductor = new Conductor(rs.getInt("ID"),
                        rs.getString("NOMBRECOMPLETO"),
                        rs.getString("TELEFONO"),
                        rs.getString("DIRECCION"),
                        rs.getDate("FECHACREACION"));

                System.out.println(conductor.getId() + " " + conductor.getNombreCompleto() + " " + conductor.getTelefono() + " " + conductor.getDireccion() + " " + conductor.getFechaCreacion());

            }

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

    }



}
