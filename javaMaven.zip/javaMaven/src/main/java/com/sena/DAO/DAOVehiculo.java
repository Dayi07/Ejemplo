package com.sena.DAO;
import com.sena.conexion.Conexion;
import com.sena.models.Vehiculo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DAOVehiculo extends Conexion {

    public void createVehiculo(Vehiculo v){
        Connection con = this.getConexion();
        String sql = "INSERT INTO Vehicle (PLACA, MODELO, MARCA, VALORCOMERCIAL) VALUES(?, ?, ?, ?)";
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, v.getPlaca());
            ps.setString(2, v.getModelo());
            ps.setString(3, v.getMarca());
            ps.setDouble(4,v.getValorComercial());

            System.out.println(ps.toString());
            ps.execute();

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }


    public Vehiculo consultarVehiculo(Vehiculo v){return null;}


    public Vehiculo ConsultarVehiculoPorModelo(String modelo){
        return null;
    }


    public void updateVehiculo(Vehiculo v){
        Connection con = this.getConexion();
        String sql = "UPDATE Vehicle SET VALORCOMERCIAL = (?) WHERE PLACA = (?)";
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setDouble(1, v.getValorComercial());
            ps.setString(2, v.getPlaca());

            System.out.println(ps.toString());
            ps.execute();

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }


    public void deleteVehiculo(Vehiculo v){
        Connection con = this.getConexion();
        String sql = "DELETE FROM Vehicle WHERE PLACA = (?) ";
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, v.getPlaca());

            System.out.println(ps.toString());
            ps.execute();

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

}


